palavra = input("Digite uma palavra: ")
palavra_invertida = palavra[::-1]

print(palavra_invertida)
