nome = input("Digite um nome: ")

if nome[0].lower() == 'a':
    print(nome)
