letra = input("Digite uma letra maiúscula: ")
letra_min = chr(ord(letra) + 32)
print(letra_min)
