string = input("Digite uma string: ")
print(len(string))
