string1 = input("Digite a primeira string: ")
string2 = input("Digite a segunda string: ")

if string1 == string2:
    print("As strings são iguais.")
else:
    print("As strings são diferentes.")
