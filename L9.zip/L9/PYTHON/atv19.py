string = input("Digite uma string em letras maiúsculas: ")

nova_string = string.lower()

print("A nova string em letras minúsculas é:", nova_string)
