palavra = input("Digite uma palavra de até 10 caracteres: ")
ultimo = palavra[-1]
print(ultimo)
