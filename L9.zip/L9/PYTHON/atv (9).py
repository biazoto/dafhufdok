string = input("Digite uma string: ")
print(string)
