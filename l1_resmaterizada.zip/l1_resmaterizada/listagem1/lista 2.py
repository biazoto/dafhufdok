caractere1 = input("Digite o primeiro caractere: ")
caractere2 = input("Digite o segundo caractere: ")

print("O usuário digitou", caractere1, "e", caractere2, "!")
