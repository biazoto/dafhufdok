n = int(input("Digite o valor de N: "))
    print(f"Os {n} primeiros múltiplos de 3 são:")
for i in range(1, n+1):
    print(i*3)
