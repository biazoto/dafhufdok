for numero in range(1000, 2000):
    if numero % 11 == 5:
        print(numero)
